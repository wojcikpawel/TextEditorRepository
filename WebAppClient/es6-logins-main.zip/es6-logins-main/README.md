# ES6-Logins

Assortment of login forms, showcasing various techniques with ES6

### Examples

- /login-1 - Password Visibility Button

### Usage

To run the project:

1. Open each example folder (separately from main project)
2. Install VS Code LiveServer Plugin
3. Smash the "Go Live" button

### Support

Hit me up on [Instagram](https://instagram.com/frontendjoe/) if you need any support :)
